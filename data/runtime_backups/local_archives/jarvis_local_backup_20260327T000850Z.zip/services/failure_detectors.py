import time
from typing import Iterable, List, Mapping, Optional

from services.repair_contracts import FailureSignal


def detect_failure_signals(
    *,
    runtime_snapshot: Mapping[str, object],
    recent_errors: Iterable[str],
    recent_routes: Iterable[Mapping[str, object]],
    heartbeat_timeout_seconds: int,
    heartbeat_exists: Optional[bool] = None,
    now_ts: Optional[int] = None,
) -> List[FailureSignal]:
    now = int(now_ts or time.time())
    signals: List[FailureSignal] = []
    error_lines = [str(item) for item in recent_errors if str(item).strip()]
    severe_error_count = int(runtime_snapshot.get("severe_error_count", 0) or 0)
    restart_count = int(runtime_snapshot.get("restart_count", 0) or 0)
    heartbeat_kill_count = int(runtime_snapshot.get("heartbeat_kill_count", 0) or 0)
    warning_count = int(runtime_snapshot.get("warning_count", 0) or 0)
    last_restart_at = int(runtime_snapshot.get("last_restart_at", 0) or 0)
    if restart_count >= 3 and last_restart_at and now - last_restart_at <= max(3600, heartbeat_timeout_seconds * 4):
        signals.append(
            FailureSignal(
                signal_code="restart_loop",
                severity="high",
                summary="Bridge похоже входит в цикл рестартов.",
                evidence=f"restart_count={restart_count}; last_restart_at={last_restart_at}",
                confidence=0.88,
                source="runtime_log",
                suggested_playbook="restart_runtime",
                problem_type="unhealthy_loop",
                detection_method="runtime_log_restart_counter",
                auto_repairable=False,
            )
        )
    if heartbeat_kill_count > 0:
        signals.append(
            FailureSignal(
                signal_code="heartbeat_stale",
                severity="high",
                summary="Supervisor уже убивал bridge из-за stale heartbeat.",
                evidence=f"heartbeat_kill_count={heartbeat_kill_count}",
                confidence=0.92,
                source="runtime_log",
                suggested_playbook="refresh_runtime_state",
                problem_type="runtime_degraded",
                detection_method="runtime_log_heartbeat_marker",
                auto_repairable=True,
            )
        )
    if any("sqlite3.operationalerror" in line.lower() and ("no such table" in line.lower() or "values for" in line.lower()) for line in error_lines):
        signals.append(
            FailureSignal(
                signal_code="sqlite_schema_mismatch",
                severity="high",
                summary="Обнаружена SQLite schema mismatch ошибка.",
                evidence=next((line for line in error_lines if "sqlite3.OperationalError" in line), error_lines[0] if error_lines else ""),
                confidence=0.95,
                source="runtime_log",
                suggested_playbook="repair_sqlite_schema",
                problem_type="sqlite_error",
                detection_method="sqlite_operational_error_log",
                auto_repairable=False,
            )
        )
    if any("database is locked" in line.lower() or "database table is locked" in line.lower() for line in error_lines):
        signals.append(
            FailureSignal(
                signal_code="sqlite_lock",
                severity="medium",
                summary="Обнаружена временная SQLite lock-ошибка.",
                evidence=next((line for line in error_lines if "locked" in line.lower()), error_lines[0] if error_lines else ""),
                confidence=0.86,
                source="runtime_log",
                suggested_playbook="recover_sqlite_lock",
                problem_type="sqlite_error",
                detection_method="sqlite_lock_error_log",
                auto_repairable=True,
            )
        )
    if warning_count >= 3 and any("lookup failed" in line.lower() for line in error_lines):
        signals.append(
            FailureSignal(
                signal_code="live_provider_degraded",
                severity="medium",
                summary="Live providers деградировали: серия lookup failures.",
                evidence=f"warning_count={warning_count}",
                confidence=0.76,
                source="runtime_log",
                suggested_playbook="recover_failed_live_provider_config",
                problem_type="live_provider_failed",
                detection_method="provider_warning_burst",
                auto_repairable=True,
            )
        )
    if heartbeat_exists is False:
        signals.append(
            FailureSignal(
                signal_code="missing_runtime_artifact",
                severity="medium",
                summary="Не найден обязательный runtime artifact heartbeat.",
                evidence="heartbeat file missing",
                confidence=0.9,
                source="filesystem_probe",
                suggested_playbook="reinitialize_missing_runtime_artifact",
                problem_type="runtime_degraded",
                detection_method="heartbeat_file_exists_probe",
                auto_repairable=True,
            )
        )
    degraded_routes = 0
    for row in recent_routes:
        outcome = str(row["outcome"] or "").strip().lower()
        route_kind = str(row["route_kind"] or "")
        if outcome not in {"ok", ""} and route_kind:
            degraded_routes += 1
    if degraded_routes >= 3:
        signals.append(
            FailureSignal(
                signal_code="route_regression",
                severity="medium",
                summary="В последних route diagnostics видно несколько деградировавших маршрутов.",
                evidence=f"degraded_routes={degraded_routes}",
                confidence=0.7,
                source="request_diagnostics",
                suggested_playbook="audit_route_regression",
                problem_type="route_drift",
                detection_method="request_diagnostics_rollup",
                auto_repairable=True,
            )
        )
    if severe_error_count > 0 and not signals:
        signals.append(
            FailureSignal(
                signal_code="severe_runtime_errors",
                severity="medium",
                summary="В хвосте лога есть severe runtime errors.",
                evidence=f"severe_error_count={severe_error_count}",
                confidence=0.64,
                source="runtime_log",
                suggested_playbook="recheck_health",
                problem_type="runtime_degraded",
                detection_method="runtime_log_severe_errors",
                auto_repairable=True,
            )
        )
    return signals


def render_failure_signals(signals: Iterable[FailureSignal]) -> str:
    items = list(signals)
    if not items:
        return "Failure signals: подтверждённых инцидентов сейчас не обнаружено."
    lines = ["Failure signals"]
    for item in items:
        lines.append(
            f"- {item.signal_code} severity={item.severity} confidence={item.confidence:.2f} source={item.source}"
        )
        lines.append(f"  {item.summary}")
        if item.evidence:
            lines.append(f"  evidence={item.evidence}")
        if item.suggested_playbook:
            lines.append(f"  suggested_playbook={item.suggested_playbook}")
    return "\n".join(lines)
