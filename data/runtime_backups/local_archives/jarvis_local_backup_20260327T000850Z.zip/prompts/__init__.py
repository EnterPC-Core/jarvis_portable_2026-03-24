"""Prompt-building helpers."""

